// src/utils/getGeoLocation.js
import API from "../services/api";
import { retry } from "./retry";

export const getGeoLocation = async () => {
  try {
    const res = await retry(() =>
      API.get("https://ipapi.co/json/", {
        baseURL: "", // override baseURL just for this external call
      })
    );
    return res.data;
  } catch (err) {
    console.error("Failed to fetch geolocation after retries", err);
    return null;
  }
};

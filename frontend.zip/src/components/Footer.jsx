import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-white border-t border-gray-200 shadow-sm dark:bg-gray-900 dark:border-gray-700">
      <div className="max-w-7xl mx-auto px-4 py-6 flex flex-col md:flex-row justify-between items-center text-sm text-gray-600 dark:text-gray-400">
        <p>&copy; {new Date().getFullYear()} ADAY - All Rights Reserved.</p>
        <div className="flex space-x-4 mt-2 md:mt-0">
          <Link to="/settings" className="hover:text-purple-600">
            Settings
          </Link>
          <a
            href="https://adaymusic.com" // Change this to your site
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-purple-600"
          >
            Website
          </a>
          <a
            href="mailto:support@adaymusic.com"
            className="hover:text-purple-600"
          >
            Support
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

import React, { useContext, useEffect, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { Dialog } from "@headlessui/react";
import { motion, AnimatePresence } from "framer-motion";
import Login from "../pages/Login";
import toast from "react-hot-toast";
import NotificationBell from "./NotificationBell";
import { FaBars, FaTimes, FaSun, FaMoon, FaUserCog, FaSignOutAlt } from "react-icons/fa";
import LinkTypeSelector from "./LinkTypeSelector";
import WorkspaceContext from '../context/WorkspaceContext';

const Navbar = () => {
  const { user, setUser } = useContext(AuthContext);
  const navigate = useNavigate();
  const location = useLocation();
  const [showDropdown, setShowDropdown] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(
    localStorage.getItem("theme") === "dark"
  );
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showLinkSelector, setShowLinkSelector] = useState(false);
  const { workspaces, current, setCurrent } = useContext(WorkspaceContext);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [darkMode]);

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to log out?")) {
      localStorage.removeItem("user");
      setUser(null);
      navigate("/");
      toast.success("Logged out successfully!");
    }
  };

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (!e.target.closest(".dropdown")) {
        setShowDropdown(false);
      }
    };
    document.addEventListener("click", handleClickOutside);
    return () => document.removeEventListener("click", handleClickOutside);
  }, []);

  useEffect(() => {
    if (user) {
      setIsModalOpen(false);
    }
  }, [user]);

  // Close mobile menu when route changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  return (
    <>
      <nav className="flex justify-between items-center p-4 bg-gray-800 text-white">
        <div className="flex items-center">
          <h1 className="text-lg font-bold">Aday Smartlinks</h1>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex gap-4 items-center">
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="bg-gray-700 p-2 rounded-full"
            aria-label="Toggle dark mode"
          >
            {darkMode ? <FaSun /> : <FaMoon />}
          </button>

          {/* Only show Home link when user is not signed in */}
          {!user && (
            <Link to="/" className="hover:text-gray-300 transition">
              Home
            </Link>
          )}

          {user ? (
            <>
              <Link to="/dashboard" className="hover:text-gray-300 transition">
                Dashboard
              </Link>
              <Link to="/analytics" className="hover:text-gray-300 transition">
                Analytics
              </Link>
              <button
                onClick={() => setShowLinkSelector(true)}
                className="hover:text-gray-300 transition"
              >
                Create Link
              </button>
              {workspaces.length > 0 && (
      <select
        className="bg-gray-700 text-white text-sm rounded px-2 py-1 focus:outline-none"
        value={current?._id || ""}
        onChange={(e) => {
          const selected = workspaces.find((w) => w._id === e.target.value);
          setCurrent(selected);
        }}
      >
        {workspaces.map((ws) => (
          <option key={ws._id} value={ws._id}>
            {ws.name}
          </option>
        ))}
      </select>
    )}

              <NotificationBell />

              <div className="relative dropdown">
                <button
                  className="flex items-center gap-2 bg-gray-700 px-3 py-1 rounded hover:bg-gray-600 transition"
                  onClick={() => setShowDropdown(!showDropdown)}
                >
                  <img
                    src={user.profileImage}
                    alt="Profile"
                    className="w-6 h-6 rounded-full object-cover"
                  />
                  <span className="hidden lg:inline">{user.name.split(" ")[0]}</span>
                </button>
                {showDropdown && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="absolute right-0 mt-2 w-48 bg-white text-black rounded shadow-lg z-50 overflow-hidden"
                  >
                    <button
                      onClick={() => {
                        navigate("/settings");
                        setShowDropdown(false);
                      }}
                      className="flex items-center w-full text-left px-4 py-2 hover:bg-gray-100 transition"
                    >
                      <FaUserCog className="mr-2" />
                      Settings
                    </button>
                    <button
                      onClick={handleLogout}
                      className="flex items-center w-full text-left px-4 py-2 hover:bg-gray-100 transition"
                    >
                      <FaSignOutAlt className="mr-2" />
                      Logout
                    </button>
                  </motion.div>
                )}
              </div>
            </>
          ) : (
            <>
              <button
                onClick={() => setIsModalOpen(true)}
                className="hover:text-gray-300 transition"
              >
                Sign In
              </button>
              <button
                onClick={() => setIsModalOpen(true)}
                className="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded transition"
              >
                Get Started
              </button>
            </>
          )}
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden text-white focus:outline-none"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
        </button>
      </nav>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="bg-gray-700 text-white md:hidden overflow-hidden"
          >
            <div className="flex flex-col space-y-4 p-4">
              <div className="flex justify-center">
                <button
                  onClick={() => setDarkMode(!darkMode)}
                  className="bg-gray-600 p-2 rounded-full"
                >
                  {darkMode ? <FaSun /> : <FaMoon />}
                </button>
              </div>

              {/* Only show Home link when user is not signed in */}
              {!user && (
                <Link
                  to="/"
                  className="block py-2 px-4 rounded hover:bg-gray-600 transition"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Home
                </Link>
              )}

              {user ? (
                <>
                  <Link
                    to="/dashboard"
                    className="block py-2 px-4 rounded hover:bg-gray-600 transition"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Dashboard
                  </Link>
                  <Link
                    to="/analytics"
                    className="block py-2 px-4 rounded hover:bg-gray-600 transition"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Analytics
                  </Link>
                  <button
                    onClick={() => {
                      setShowLinkSelector(true);
                      setMobileMenuOpen(false);
                    }}
                    className="block py-2 px-4 rounded hover:bg-gray-600 transition text-left"
                  >
                    Create Link
                  </button>

                  <div className="border-t border-gray-600 pt-2 mt-2">
                    <Link
                      to="/settings"
                      className="flex items-center py-2 px-4 rounded hover:bg-gray-600 transition"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <FaUserCog className="mr-2" />
                      Settings
                    </Link>
                    <button
                      onClick={() => {
                        handleLogout();
                        setMobileMenuOpen(false);
                      }}
                      className="flex items-center w-full py-2 px-4 rounded hover:bg-gray-600 transition text-left"
                    >
                      <FaSignOutAlt className="mr-2" />
                      Logout
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <button
                    onClick={() => {
                      setIsModalOpen(true);
                      setMobileMenuOpen(false);
                    }}
                    className="block py-2 px-4 rounded hover:bg-gray-600 transition text-left"
                  >
                    Sign In
                  </button>
                  <button
                    onClick={() => {
                      setIsModalOpen(true);
                      setMobileMenuOpen(false);
                    }}
                    className="bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded transition text-center"
                  >
                    Get Started
                  </button>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Login Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <Dialog
            open={isModalOpen}
            onClose={() => setIsModalOpen(false)}
            className="fixed inset-0 z-50 flex items-center justify-center"
          >
            <div className="fixed inset-0 bg-black/50 backdrop-blur-sm" />

            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
              className="bg-white dark:bg-gray-800 p-6 rounded z-50 w-full max-w-md mx-4"
            >
              <Dialog.Title className="text-lg mb-4 text-center dark:text-white">
                Sign in to Aday Smartlinks
              </Dialog.Title>
              <Login />
              <button
                onClick={() => setIsModalOpen(false)}
                className="mt-4 bg-gray-700 text-white px-4 py-2 rounded w-full hover:bg-gray-600 transition"
              >
                Close
              </button>
            </motion.div>
          </Dialog>
        )}
      </AnimatePresence>

      {/* Link Type Selector Modal */}
      {showLinkSelector && (
        <LinkTypeSelector onClose={() => setShowLinkSelector(false)} />
      )}
    </>
  );
};

export default Navbar;
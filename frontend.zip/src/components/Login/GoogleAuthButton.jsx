import React from "react";
import { GoogleLogin } from "@react-oauth/google";
import { jwtDecode } from 'jwt-decode';
import API from "../../services/api";
import toast from "react-hot-toast";
import { BASE_DOMAIN } from "../../config";

const GoogleAuthButton = ({ setUser, setLoading }) => {
  const handleSuccess = async (credentialResponse) => {
    try {
      setLoading(true);
      const decoded = jwtDecode(credentialResponse.credential);
      const userPayload = {
        googleId: decoded.sub,
        name: decoded.name,
        email: decoded.email,
        profileImage: decoded.picture,
      };

      const hostname = window.location.hostname;
      const mainDomain = "localhost"; // Replace with "aday.io" in prod

      if (hostname !== mainDomain && hostname.includes(".")) {
        userPayload.username = hostname.split(".")[0];
      }

      const { token, user } = await API.post("/auth/google", userPayload).then((r) => r.data);
      localStorage.setItem("token", token);
      localStorage.setItem("user", JSON.stringify(user));
      setUser(user);
      toast.success(`Welcome ${decoded.name.split(" ")[0]}! 🎉`);

      const pendingPlan = sessionStorage.getItem("pendingPlan");
      sessionStorage.removeItem("pendingPlan");

      if (pendingPlan) {
        window.location.href = `/subscription?plan=${pendingPlan}`;
      } else {
        window.location.href = user?.subscriptionPlan ? "/dashboard" : "/subscription";
      }
    } catch (error) {
      console.error("Login Error:", error);
      toast.error("Login Failed!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <GoogleLogin
      onSuccess={handleSuccess}
      onError={() => toast.error("Google Login Failed")}
    />
  );
};

export default GoogleAuthButton;

import React from "react";
import CampaignOverviewTable from "../CampaignOverviewTable";
import TaskSuggestions from "../TaskSuggestions";
import { Sparkles } from "lucide-react";

const CampaignTable = ({ campaigns, tasks }) => {
  return (
    <div className="space-y-6">
      <CampaignOverviewTable campaigns={campaigns} />

      <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-blue-50 to-blue-100 dark:from-gray-700 dark:to-gray-800">
          <h3 className="font-medium flex items-center gap-2">
            <Sparkles size={18} className="text-yellow-500" />
            Getting Started
          </h3>
        </div>
        <div className="p-4">
          <TaskSuggestions tasks={tasks} />
        </div>
      </div>
    </div>
  );
};

export default CampaignTable;

import React, { useContext } from "react";
import { AuthContext } from "../../context/AuthContext";
import ProfileInfo from "../../components/Settings/ProfileInfo";
import SubdomainSettings from "../../components/Settings/SubdomainSettings";
import CustomDomainSettings from "../../components/Settings/CustomDomainSettings";
import PasswordSettings from "../../components/Settings/PasswordSettings";
import TwoFactorSettings from "../../components/TwoFactorSettings";

const SettingsPage = () => {
  const { user, setUser } = useContext(AuthContext);

  return (
    <div className="p-6 max-w-lg mx-auto">
      <h2 className="text-2xl mb-4">Account Settings</h2>

      <ProfileInfo user={user} setUser={setUser} />
      {user?.isPremium && <SubdomainSettings user={user} setUser={setUser} />}
      {user?.isPremium && <CustomDomainSettings user={user} setUser={setUser} />}
      <PasswordSettings user={user} />
      <TwoFactorSettings />
    </div>
  );
};

export default SettingsPage;

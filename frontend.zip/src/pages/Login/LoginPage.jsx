import React, { useContext, useState } from "react";
import { AuthContext } from "../../context/AuthContext";
import GoogleAuthButton from "../../components/Login/GoogleAuthButton";

const LoginPage = () => {
  const { setUser } = useContext(AuthContext);
  const [loading, setLoading] = useState(false);

  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <h2 className="text-2xl mb-4">Sign in to Aday Smartlinks</h2>
      <GoogleAuthButton setUser={setUser} setLoading={setLoading} />
      {loading && <p className="text-sm mt-2">Signing in...</p>}
    </div>
  );
};

export default LoginPage;

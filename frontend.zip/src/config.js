// src/config.js
export const PUBLIC_VAPID_KEY = "BDtce2AGBN31-zYueaoEx4GDDEf05tWPl5a8LrHJc6f_Muli2lT6T1FY4UtdocURdBCWq61l3RR1M0KUrXlIvOQ";
export const BASE_DOMAIN = process.env.REACT_APP_BASE_DOMAIN || 'localhost';

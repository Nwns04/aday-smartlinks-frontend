import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import API from "../services/api";
import { toast } from "react-hot-toast";
import useSpotifyProfile from "./useSpotifyProfile";

const welcomeMessages = [
  "Good to see you again,", "You're back on the grind,", "Let's get things rolling,", "Hey Rockstar,",
  "Ready to dominate today,", "Welcome back, legend", "Another day, another win,", "Time to make moves,",
  "Look who's back,", "Back to the dashboard,"
];

export default function useDashboardData(user, setUser, navigate, searchParams) {
  const [activities, setActivities] = useState([]);
  const [showCelebration, setShowCelebration] = useState(false);
  const [greeting, setGreeting] = useState("");

  const { spotifyStatus, setSpotifyProfile, updateSpotifyUser } = useSpotifyProfile(user, setUser);

  const {
    data: analytics = [],
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["dashboardAnalytics", user?._id],
    queryFn: async () => {
      const res = await API.get(`/campaigns/analytics/${user._id}`);
      return res.data;
    },
    enabled: Boolean(user?._id),
    staleTime: 1000 * 60 * 5,
    retry: 2,
    onError: () => toast.error("Failed to load analytics"),
    onSuccess: (data) => {
      const acts = ["Fetched your campaign analytics"];
      if (data.length > 0) acts.push(`Your top campaign is '${data[0].title}'`);
      setActivities((prev) => [...prev, ...acts]);
    },
  });

  // --- 1. Handle Spotify connection callback (only once) ---
  useEffect(() => {
    const spotifyParam = searchParams.get("spotify");

    if (spotifyParam === "connected") {
      updateSpotifyUser().then(() => {
        navigate("/dashboard", { replace: true });
      });
    } else if (spotifyParam === "error") {
      toast.error("Failed to connect Spotify");
      navigate("/dashboard", { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 
  // 🚨 Notice: NO user, NO updateSpotifyUser in deps! 
  // Just run ONCE on mount after login redirect.

  // --- 2. Spotify Account already linked (normal user flow) ---
  useEffect(() => {
    if (user?.spotifyId) {
      setActivities((prev) => [...prev, "Spotify account connected"]);
    }
  }, [user?.spotifyId]);

  // --- 3. Celebration if clicks >= 100 ---
  useEffect(() => {
    const hasCelebrated = localStorage.getItem("hasCelebrated");
    const totalClicks = analytics.reduce((sum, c) => sum + c.clicks, 0);
    if (totalClicks >= 100 && !hasCelebrated) {
      setShowCelebration(true);
      localStorage.setItem("hasCelebrated", "true");
    }
  }, [analytics]);

  // --- 4. Random Greeting ---
  useEffect(() => {
    if (!isLoading) {
      setGreeting(welcomeMessages[Math.floor(Math.random() * welcomeMessages.length)]);
    }
  }, [isLoading]);

  return {
    analytics,
    loading: isLoading,
    error: isError,
    spotifyStatus,
    activities,
    showCelebration,
    greeting,
    setShowCelebration,
    setSpotifyProfile,
  };
}

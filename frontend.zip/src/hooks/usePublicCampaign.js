import { useQuery } from '@tanstack/react-query';
import API from '../services/api';

export default function usePublicCampaign(slug) {
  return useQuery(
    ['publicCampaign', slug],
    async () => {
      const { data } = await API.get(`/campaigns/public/${slug}`);
      return data;
    },
    {
      enabled: !!slug,   // only run when slug is truthy
      retry: 2,         // exponential retry
    }
  );
}

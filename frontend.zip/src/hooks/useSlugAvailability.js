import { useState, useCallback, useEffect } from 'react';
import debounce from 'lodash.debounce';
import API from '../services/api';

export default function useSlugAvailability(initial = '') {
  const [slug, setSlug] = useState(initial);
  const [available, setAvailable] = useState(null);
  const [loading, setLoading] = useState(false);

  const checkSlugAvailability = useCallback(debounce(async (s) => {
    if (!s) return setAvailable(null);
    setLoading(true);
    try {
      const { data } = await API.get(`/campaigns/check-slug/${s}`); // 🛑 Also fix typo in URL (your old one had a wrong dash)
      setAvailable(data.available);
    } catch {
      setAvailable(false);
    } finally {
      setLoading(false);
    }
  }, 300), []);

  useEffect(() => {
    checkSlugAvailability(slug);
  }, [slug, checkSlugAvailability]);

  return {
    slug,
    slugAvailable: available,
    slugLoading: loading,
    setSlug,
    checkSlugAvailability,   // ✅ RETURN IT HERE
  };
}

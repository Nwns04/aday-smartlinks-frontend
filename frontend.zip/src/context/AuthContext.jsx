import { createContext, useState, useEffect } from "react";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem("user") || "null";
      setUser(JSON.parse(storedUser));
    } catch (err) {
      console.error("Failed to parse user from localStorage:", err);
      localStorage.removeItem("user"); // Optionally clear corrupted entry
      setUser(null);
    } finally {
      setAuthLoading(false);
    }
  }, []);

  if (authLoading) {
    return <div className="text-center py-20">Loading...</div>; // or a spinner
  }

  return (
    <AuthContext.Provider value={{ user, setUser }}>
      {children}
    </AuthContext.Provider>
  );
};
